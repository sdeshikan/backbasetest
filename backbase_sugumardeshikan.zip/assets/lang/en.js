﻿var languageEN = {
    HEADING_APP: "Backbase FE test from Sugumar Deshikan",
    CITY_NAME : "City",
    TEMPERATURE : "Temperature",
    WIND_SPEED : "Wind Speed"
};
