/* 
 * Weather Controller.
 */
weatherApp.controller("weatherController", function ($scope, $window, commonService) {

    $scope.weatherList = [];

    /**
     * Get Cities
     * @returns {Array|weather_controller.$scope.weatherList}
     */
    
    
    $scope.getCities = function () {
        var rs = [];
        angular.forEach(APP_CONFIGURATION.CITIES, function (value) {
            $scope.getData(value);
        });
        return $scope.weatherList;
    };

    /*
     * Get Data
     * @param {type} name
     * @returns {undefined}
     */
    $scope.getData = function (name) {
        var tempData = [];
        commonService.getCityInformationByName(name).then(function (response) {
            tempData = response;
        }).finally(function () {
            $scope.weatherList.push(tempData);
            $window.sessionStorage.setItem("weatherList", $scope.weatherList);
        });
    };

    $scope.cities = $scope.getCities();

});
