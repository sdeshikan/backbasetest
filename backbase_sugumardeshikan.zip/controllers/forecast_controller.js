/* 
 * Forecast Controller.
 */
weatherApp.controller("forecastController", function ($scope, $routeParams, commonService) {

	$scope.countryName = $routeParams.name;

	$scope.getForecastInfo = function() {
		commonService.getNextDaysInformationById($routeParams.name).then(function(result) {
			$scope.forecastList = result.list.forecastArr;
			$scope.chartList = result.list.chartArr
		})
	}
	$scope.isChart = false;

	$scope.options = {
			chart: {
				type: 'pieChart',
				height: 500,
				x: function(d){return d.key;},
				y: function(d){return d.y;},
				showLabels: true,
				duration: 500,
				labelThreshold: 0.01,
				labelSunbeamLayout: true,
				legend: {
					margin: {
						top: 5,
						right: 35,
						bottom: 5,
						left: 0
					}
				}
			}
	}; 

	$scope.forecastInfo = $scope.getForecastInfo();

});

