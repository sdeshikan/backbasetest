/* 
 * App Config file.
 */
var weatherApp = angular.module("weatherApp", ["ngRoute", "nvd3",
	"ngMessages", "ngCookies", "pascalprecht.translate"]);

var LANG_EN = "en";

var APP_CONFIGURATION = {
		WEBSERVICE_PATH: "http://api.openweathermap.org/data/2.5/",
		API_KEY: "3d8b309701a13f65b660fa2c64cdc517",
		CITIES: ["London", "Bern", "Paris", "Madrid", "Berlin"]
};

weatherApp.config(function ($routeProvider, $locationProvider, $translateProvider) {
	$routeProvider
	.when("/weather", {
		templateUrl: "views/weather.html",
		controller: "weatherController"
	})
	.when("/forecast/:name", {
		templateUrl: "views/forecast.html",
		controller: "forecastController"
	})
	.otherwise({
		redirectTo: "/weather"
	});


	$translateProvider.translations("en", languageEN);
	$translateProvider.registerAvailableLanguageKeys(["en"], {
		en_US: "en",
		en_UK: "en"
	});
	$translateProvider.preferredLanguage(LANG_EN);
	$translateProvider.fallbackLanguage(LANG_EN);
	$translateProvider.useSanitizeValueStrategy("escape");
});

