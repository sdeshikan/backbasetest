

/**
 * Common Service to fetch all web service data and utilities
 */
weatherApp.service("commonService", function ($http, $location, $translate, $filter) {
	
	var getForecastAtNoon = function(arr) {
		var returnObj = {
				forecastArr: [],
				chartArr: []
		};
		
    	angular.forEach(arr, function(value, key) {
    		if(value.dt_txt.indexOf("12:00:00") !== -1){
    			returnObj.forecastArr.push(value);
    			var chartObj = {
    					key: $filter('date')(value.dt * 1000),
    					y: value.main.temp
    			};
    			returnObj.chartArr.push(chartObj);
    		}
    	});
    	return returnObj;
    }

    return {
        getCityInformationByName: function (name) {
            var promise = $http.get(APP_CONFIGURATION.WEBSERVICE_PATH + "weather?q=" + name + "&appid=" + APP_CONFIGURATION.API_KEY)
                    .then(function (result) {
                        if (result.status == 200) {
                            return {cityId: result.data.id, cityName: result.data.name, averageTemperature: result.data.main.temp,
                                windStrength: result.data.wind.speed};
                        } else {
                            console.log("api error: " + name);
                        }
                    });

            return promise;
        },
        getNextDaysInformationById: function (name) {
        	var promise = $http.get(APP_CONFIGURATION.WEBSERVICE_PATH + "forecast?q=" + name + "&appid=" + APP_CONFIGURATION.API_KEY)
                    .then(function (result) {
                        if (result.status == 200) {                            
                            return {
                                list: getForecastAtNoon(result.data.list),
                            };
                        } else {
                        	console.log("api error: " + name);
                        }
                    });

            return promise;
        },
        
    }
});
